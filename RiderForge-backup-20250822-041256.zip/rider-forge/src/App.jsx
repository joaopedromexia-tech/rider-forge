import { useState } from 'react'
import RiderForm from './components/RiderForm'
import MyRiders from './components/MyRiders'
import ProStatusBadge from './components/ProStatusBadge'
import FeedbackContainer from './components/FeedbackContainer'
import { useFeedback } from './hooks/useFeedback'
import { EquipmentProvider } from './context/EquipmentContext'
import { RiderProvider } from './context/RiderContext'

function App() {
  const { toasts, removeToast } = useFeedback()
  const [currentView, setCurrentView] = useState('home') // 'home', 'form', 'myRiders'
  const [editingRiderId, setEditingRiderId] = useState(null)

  const handleCreateRider = () => {
    setEditingRiderId(null)
    setCurrentView('form')
  }

  const handleBackToHome = () => {
    setCurrentView('home')
    setEditingRiderId(null)
  }

  const handleShowMyRiders = () => {
    setCurrentView('myRiders')
  }

  const handleEditRider = (riderId) => {
    setEditingRiderId(riderId)
    setCurrentView('form')
  }

  return (
    <RiderProvider>
      {currentView === 'form' && (
        <EquipmentProvider>
          <RiderForm onBack={handleBackToHome} editingRiderId={editingRiderId} />
          <FeedbackContainer toasts={toasts} onRemoveToast={removeToast} />
        </EquipmentProvider>
      )}

      {currentView === 'myRiders' && (
        <>
          <MyRiders onBack={handleBackToHome} onEditRider={handleEditRider} />
          <FeedbackContainer toasts={toasts} onRemoveToast={removeToast} />
        </>
      )}

      {currentView === 'home' && (
        <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-800 relative overflow-hidden">
          {/* Pro Status Badge */}
          <div className="absolute top-4 right-4 sm:top-6 sm:right-6 z-20 flex items-center gap-2 sm:gap-4">
            <ProStatusBadge />
          </div>

          {/* Background Pattern */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-32 -right-32 sm:-top-48 sm:-right-48 w-64 h-64 sm:w-[500px] sm:h-[500px] bg-accent-blue/3 rounded-full blur-3xl animate-float"></div>
            <div className="absolute -bottom-32 -left-32 sm:-bottom-48 sm:-left-48 w-64 h-64 sm:w-[500px] sm:h-[500px] bg-accent-green/3 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
            <div className="absolute top-1/3 left-1/4 w-48 h-48 sm:w-80 sm:h-80 bg-purple-500/2 rounded-full blur-2xl animate-pulse-slow"></div>
          </div>

          {/* Main Content */}
          <div className="relative z-10 flex items-center justify-center min-h-screen p-4">
            <div className="text-center max-w-4xl mx-auto animate-fade-in w-full">
              {/* Logo/Icon */}
              <div className="mb-4 flex justify-center">
                <div className="w-16 h-16 bg-gradient-to-br from-accent-blue via-blue-500 to-accent-green rounded-2xl flex items-center justify-center shadow-2xl shadow-accent-blue/25 animate-bounce-gentle group hover:shadow-glow-blue transition-all duration-500">
                  <svg className="w-8 h-8 text-white group-hover:scale-110 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
              </div>

              {/* Main Title */}
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-4 animate-slide-in leading-tight">
                <span className="text-gradient bg-gradient-to-r from-accent-blue via-blue-400 to-accent-green bg-clip-text text-transparent">Rider</span>
                <span className="text-gray-100"> Forge</span>
              </h1>

              {/* Subtitle */}
              <p className="text-base sm:text-lg md:text-xl text-gray-400 mb-6 max-w-2xl mx-auto leading-relaxed animate-fade-in px-4" style={{ animationDelay: '0.3s' }}>
                Crie riders técnicos profissionais de forma rápida e eficiente
              </p>

              {/* CTA Buttons */}
              <div className="animate-fade-in flex flex-col items-center justify-center gap-3 px-4 mb-8" style={{ animationDelay: '0.6s' }}>
                <button
                  onClick={handleCreateRider}
                  className="btn-primary text-base sm:text-lg font-bold relative overflow-hidden group w-full max-w-sm px-6 py-3"
                >
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    <svg 
                      className="w-5 h-5 transition-transform duration-300 group-hover:rotate-12" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    Criar Rider
                  </span>
                  
                  {/* Button Background Animation */}
                  <div className="absolute inset-0 bg-gradient-to-r from-accent-green to-accent-blue opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </button>

                <button
                  onClick={handleShowMyRiders}
                  className="btn-secondary text-base sm:text-lg font-bold relative overflow-hidden group w-full max-w-sm px-6 py-3"
                >
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    <svg 
                      className="w-5 h-5 transition-transform duration-300 group-hover:rotate-12" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    Os Meus Riders
                  </span>
                </button>
              </div>

              {/* Features Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl mx-auto animate-fade-in px-4" style={{ animationDelay: '0.9s' }}>
                <div className="card-featured group">
                  <div className="w-12 h-12 bg-accent-blue/20 rounded-xl flex items-center justify-center mb-3 group-hover:bg-accent-blue/30 transition-all duration-300 group-hover:scale-110">
                    <svg className="w-6 h-6 text-accent-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-gray-100 mb-2">Precisão Técnica</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">Crie riders detalhados com especificações técnicas precisas para cada equipamento</p>
                </div>

                <div className="card-featured group">
                  <div className="w-12 h-12 bg-accent-green/20 rounded-xl flex items-center justify-center mb-3 group-hover:bg-accent-green/30 transition-all duration-300 group-hover:scale-110">
                    <svg className="w-6 h-6 text-accent-green" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-gray-100 mb-2">Rápido e Eficiente</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">Interface intuitiva que permite criar riders profissionais em minutos</p>
                </div>

                <div className="card-featured group">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mb-3 group-hover:bg-purple-500/30 transition-all duration-300 group-hover:scale-110">
                    <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-gray-100 mb-2">Profissional</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">Exporte riders em PDF com design profissional e layout otimizado</p>
                </div>
              </div>
            </div>
          </div>

          {/* Feedback Container */}
          <FeedbackContainer toasts={toasts} onRemoveToast={removeToast} />
        </div>
      )}
    </RiderProvider>
  )
}

export default App
