import { processPDFSimple } from './simplePdfProcessor'

// Este arquivo agora usa o processador simplificado

// Funções removidas - agora usa o processador simplificado

// Funções de parsing removidas - agora usa o processador simplificado

/**
 * Testa se um PDF pode ser processado
 * @param {File} file - Arquivo PDF
 * @returns {Promise<Object>} Informações sobre o PDF
 */
export const testPDFFile = async (file) => {
  try {
    console.log('Testando PDF:', file.name)
    
    // Verificações básicas
    const info = {
      name: file.name,
      size: file.size,
      type: file.type,
      isValid: false,
      canExtractText: false,
      pages: 0,
      textLength: 0,
      issues: []
    }
    
    // Verificar tipo
    if (file.type !== 'application/pdf') {
      info.issues.push('Tipo de arquivo inválido')
      return info
    }
    
    // Verificar tamanho
    if (file.size > 50 * 1024 * 1024) {
      info.issues.push('Arquivo muito grande (>50MB)')
      return info
    }
    
    info.isValid = true
    
    // Tentar extrair texto
    try {
      const text = await extractTextFromPDF(file)
      info.canExtractText = true
      info.textLength = text.length
      
      // Tentar obter número de páginas
      const arrayBuffer = await file.arrayBuffer()
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise
      info.pages = pdf.numPages
      
    } catch (textError) {
      info.issues.push(`Erro ao extrair texto: ${textError.message}`)
    }
    
    return info
  } catch (error) {
    return {
      name: file.name,
      isValid: false,
      issues: [`Erro geral: ${error.message}`]
    }
  }
}

/**
 * Processa um arquivo PDF e extrai dados de rider
 * @param {File} file - Arquivo PDF
 * @returns {Promise<Object>} Dados estruturados do rider
 */
export const processPDFRider = async (file) => {
  try {
    console.log('Iniciando processamento do PDF:', file.name, 'Tamanho:', file.size, 'bytes')
    
    // Usar o processador simplificado
    return await processPDFSimple(file)
  } catch (error) {
    console.error('Erro ao processar PDF:', error)
    
    // Fornecer mensagens de erro mais específicas
    if (error.message.includes('Arquivo inválido')) {
      throw new Error('O arquivo selecionado não é um PDF válido. Por favor, selecione um arquivo PDF.')
    }
    
    if (error.message.includes('muito grande')) {
      throw new Error('O arquivo PDF é muito grande. O tamanho máximo é 50MB.')
    }
    
    if (error.message.includes('Não foi possível extrair texto')) {
      throw new Error('Não foi possível extrair texto do PDF. O arquivo pode estar protegido, corrompido ou não conter texto extraível.')
    }
    
    if (error.message.includes('Nenhum texto foi extraído')) {
      throw new Error('O PDF não contém texto extraível. Tente com um PDF que tenha texto selecionável.')
    }
    
    // Erro genérico com sugestões
    throw new Error(`Erro ao processar PDF: ${error.message}. Tente com um PDF diferente ou verifique se o arquivo não está corrompido.`)
  }
}
