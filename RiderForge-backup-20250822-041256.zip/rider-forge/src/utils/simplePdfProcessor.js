import * as pdfjsLib from 'pdfjs-dist'

// Configurar worker de forma mais simples
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js'

/**
 * Processador de PDF simplificado e confiável
 * @param {File} file - Arquivo PDF
 * @returns {Promise<Object>} Dados estruturados do rider
 */
export const processPDFSimple = async (file) => {
  try {
    console.log('Processando PDF com método simplificado...')
    
    // Verificações básicas
    if (!file || file.type !== 'application/pdf') {
      throw new Error('Arquivo inválido. Por favor, selecione um arquivo PDF válido.')
    }
    
    if (file.size > 50 * 1024 * 1024) {
      throw new Error('Arquivo muito grande. O tamanho máximo é 50MB.')
    }
    
    // Carregar PDF
    const arrayBuffer = await file.arrayBuffer()
    const pdf = await pdfjsLib.getDocument(arrayBuffer).promise
    
    console.log(`PDF carregado com ${pdf.numPages} páginas`)
    
    // Extrair texto de todas as páginas
    let fullText = ''
    
    for (let i = 1; i <= pdf.numPages; i++) {
      try {
        const page = await pdf.getPage(i)
        const textContent = await page.getTextContent()
        
        const pageText = textContent.items
          .map(item => item.str || '')
          .join(' ')
          .trim()
        
        if (pageText) {
          fullText += pageText + '\n'
        }
        
        console.log(`Página ${i} processada: ${pageText.length} caracteres`)
      } catch (pageError) {
        console.warn(`Erro ao processar página ${i}:`, pageError)
        // Continuar com as próximas páginas
      }
    }
    
    if (!fullText.trim()) {
      throw new Error('Não foi possível extrair texto do PDF. O arquivo pode estar vazio ou não conter texto extraível.')
    }
    
    console.log('Texto extraído (primeiros 200 caracteres):', fullText.substring(0, 200))
    
    // Processar o texto extraído
    const riderData = parseRiderFromText(fullText)
    
    // Gerar nome
    const dadosGerais = riderData['dados-gerais'] || {}
    const name = dadosGerais.artista || dadosGerais.local || 'Rider Importado do PDF'
    
    return {
      name,
      data: riderData
    }
  } catch (error) {
    console.error('Erro ao processar PDF:', error)
    throw new Error(`Erro ao processar PDF: ${error.message}`)
  }
}

/**
 * Extrai informações de rider de texto
 * @param {string} text - Texto extraído do PDF
 * @returns {Object} Dados estruturados do rider
 */
const parseRiderFromText = (text) => {
  const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0)
  
  const riderData = {
    'dados-gerais': {},
    'pa': {},
    'consolas': {},
    'sistemas-escuta': {},
    'equipamento-auxiliar': {},
    'input-list': {},
    'monitor-mixes': {},
    'observacoes-finais': {}
  }

  let currentSection = null

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].toLowerCase()
    
    // Detectar seções principais
    if (line.includes('dados gerais') || line.includes('informações gerais')) {
      currentSection = 'dados-gerais'
      continue
    } else if (line.includes('pa') || line.includes('sistema de som') || line.includes('sistema principal')) {
      currentSection = 'pa'
      continue
    } else if (line.includes('consola') || line.includes('console') || line.includes('mesa')) {
      currentSection = 'consolas'
      continue
    } else if (line.includes('escuta') || line.includes('monitor') || line.includes('iem')) {
      currentSection = 'sistemas-escuta'
      continue
    } else if (line.includes('equipamento auxiliar') || line.includes('equipamentos auxiliares')) {
      currentSection = 'equipamento-auxiliar'
      continue
    } else if (line.includes('input list') || line.includes('lista de entradas')) {
      currentSection = 'input-list'
      continue
    } else if (line.includes('monitor mixes') || line.includes('misturas de monitor')) {
      currentSection = 'monitor-mixes'
      continue
    } else if (line.includes('observações') || line.includes('notas') || line.includes('comentários')) {
      currentSection = 'observacoes-finais'
      continue
    }

    // Processar dados baseado na seção atual
    if (currentSection === 'dados-gerais') {
      if (line.includes('artista') || line.includes('banda')) {
        const value = extractValue(lines, i)
        if (value) riderData['dados-gerais'].artista = value
      } else if (line.includes('local') || line.includes('venue')) {
        const value = extractValue(lines, i)
        if (value) riderData['dados-gerais'].local = value
      } else if (line.includes('data') || line.includes('date')) {
        const value = extractValue(lines, i)
        if (value) riderData['dados-gerais'].data = value
      } else if (line.includes('hora') || line.includes('time')) {
        const value = extractValue(lines, i)
        if (value) riderData['dados-gerais'].hora = value
      }
    } else if (currentSection === 'pa') {
      if (line.includes('sistema') || line.includes('pa')) {
        const value = extractValue(lines, i)
        if (value) {
          if (!riderData['pa'].sistema) riderData['pa'].sistema = []
          riderData['pa'].sistema.push(value)
        }
      }
    } else if (currentSection === 'consolas') {
      if (line.includes('consola') || line.includes('console')) {
        const value = extractValue(lines, i)
        if (value) {
          if (!riderData['consolas'].consola) riderData['consolas'].consola = []
          riderData['consolas'].consola.push(value)
        }
      }
    } else if (currentSection === 'sistemas-escuta') {
      if (line.includes('escuta') || line.includes('monitor')) {
        const value = extractValue(lines, i)
        if (value) {
          if (!riderData['sistemas-escuta'].sistema) riderData['sistemas-escuta'].sistema = []
          riderData['sistemas-escuta'].sistema.push(value)
        }
      }
    } else if (currentSection === 'equipamento-auxiliar') {
      if (line.includes('equipamento') || line.includes('equip')) {
        const value = extractValue(lines, i)
        if (value) {
          if (!riderData['equipamento-auxiliar'].equipamento) riderData['equipamento-auxiliar'].equipamento = []
          riderData['equipamento-auxiliar'].equipamento.push(value)
        }
      }
    } else if (currentSection === 'observacoes-finais') {
      if (!riderData['observacoes-finais'].observacoes) {
        riderData['observacoes-finais'].observacoes = []
      }
      riderData['observacoes-finais'].observacoes.push(lines[i])
    }
  }

  // Limpar seções vazias
  Object.keys(riderData).forEach(key => {
    if (Object.keys(riderData[key]).length === 0) {
      delete riderData[key]
    }
  })

  return riderData
}

/**
 * Extrai valor após dois pontos ou igual
 */
const extractValue = (lines, index) => {
  const line = lines[index]
  const colonIndex = line.indexOf(':')
  const equalIndex = line.indexOf('=')
  
  if (colonIndex !== -1) {
    return line.substring(colonIndex + 1).trim()
  } else if (equalIndex !== -1) {
    return line.substring(equalIndex + 1).trim()
  }
  
  // Tentar próxima linha se a atual não tem valor
  if (index + 1 < lines.length) {
    const nextLine = lines[index + 1]
    if (nextLine && !nextLine.includes(':') && !nextLine.includes('=')) {
      return nextLine.trim()
    }
  }
  
  return null
}
