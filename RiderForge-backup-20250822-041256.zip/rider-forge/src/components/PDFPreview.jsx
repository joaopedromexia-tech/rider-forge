import { useState, useMemo } from 'react'

function PDFPreview({ isOpen, riderData, riderName, onClose, onExport, exportOptions = { includeStagePlot: true, customFooter: '', theme: 'base', compactLayout: false } }) {
  const [currentPage, setCurrentPage] = useState(1)
  const hasStagePlot = Boolean(riderData['dados-gerais']?.stagePlot?.data) && exportOptions.includeStagePlot

  // Theme styles to mirror export
  const themeStyles = useMemo(() => {
    const theme = exportOptions?.theme || 'base'
    if (theme === 'pro_modern') {
      return {
        sectionTitleBg: 'rgb(244,246,248)',
        sectionTitleText: 'rgb(40,40,40)',
        tableHeaderBg: 'rgb(238,242,255)',
        tableHeaderText: 'rgb(60,60,60)',
        separatorColor: 'rgb(220,220,220)',
        sectionTopSpacingCls: 'mt-2'
      }
    }
    if (theme === 'pro_minimal') {
      return {
        sectionTitleBg: '',
        sectionTitleText: 'rgb(30,30,30)',
        tableHeaderBg: '',
        tableHeaderText: 'rgb(70,70,70)',
        separatorColor: 'rgb(230,230,230)',
        sectionTopSpacingCls: 'mt-1'
      }
    }
    return {
      sectionTitleBg: '',
      sectionTitleText: 'rgb(50,50,50)',
      tableHeaderBg: 'rgb(240,240,240)',
      tableHeaderText: 'rgb(100,100,100)',
      separatorColor: 'rgb(220,220,220)',
      sectionTopSpacingCls: 'mt-3'
    }
  }, [exportOptions?.theme])

  const formatDate = (dateString) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    return date.toLocaleDateString('pt-PT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  }

  const SectionTitle = ({ children }) => (
    <div className={`mb-3`}>
      <div
        className="inline-block px-1 py-0.5 rounded"
        style={{ background: themeStyles.sectionTitleBg || 'transparent' }}
      >
        <h2 className="text-xl font-bold" style={{ color: themeStyles.sectionTitleText }}>{children}</h2>
      </div>
    </div>
  )

  const Separator = () => (
    <div className="my-4" style={{ borderBottom: `1px solid ${themeStyles.separatorColor}` }} />
  )

  const renderCapa = () => (
    <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
      {/* Título */}
      <div className="text-center mb-8">
        <h1 className="text-gray-600 text-lg font-bold mb-4">RIDER TÉCNICO</h1>
        <h2 className="text-3xl font-bold text-black">
          {riderData['dados-gerais']?.artista || 'Artista'}
        </h2>
      </div>

      {/* Versão do Rider e Ano da Tour */}
      <div className="text-center mb-8">
        <p className="text-lg text-gray-700">
          {riderData['dados-gerais']?.versaoRider && `Versão ${riderData['dados-gerais'].versaoRider}`}
          {riderData['dados-gerais']?.versaoRider && riderData['dados-gerais']?.anoTour && ' • '}
          {riderData['dados-gerais']?.anoTour && `Tour ${riderData['dados-gerais'].anoTour}`}
        </p>
      </div>

      {/* Imagem de Capa */}
      {riderData['dados-gerais']?.imagemCapa?.data && (
        <div className="mb-8">
          <img src={riderData['dados-gerais'].imagemCapa.data} alt="Capa" className="w-full max-h-64 object-contain border border-gray-300" />
        </div>
      )}

      {/* Contactos */}
      <div className="max-w-md mx-auto">
        <h3 className="text-sm font-bold text-gray-600 text-center mb-4">CONTACTOS PRINCIPAIS</h3>
        {riderData['dados-gerais']?.roadManager?.nome && (
          <div className="mb-4">
            <span className="font-bold text-sm">Road Manager:</span>
            <span className="ml-2 text-sm">{riderData['dados-gerais'].roadManager.nome}</span>
            {riderData['dados-gerais'].roadManager.telefone && (
              <div className="ml-4 text-sm">Tel: {riderData['dados-gerais'].roadManager.telefone}</div>
            )}
            {riderData['dados-gerais'].roadManager.email && (
              <div className="ml-4 text-sm">Email: {riderData['dados-gerais'].roadManager.email}</div>
            )}
          </div>
        )}
        {riderData['dados-gerais']?.foh?.nome && (
          <div className="mb-4">
            <span className="font-bold text-sm">FOH:</span>
            <span className="ml-2 text-sm">{riderData['dados-gerais'].foh.nome}</span>
            {riderData['dados-gerais'].foh.telefone && (
              <div className="ml-4 text-sm">Tel: {riderData['dados-gerais'].foh.telefone}</div>
            )}
            {riderData['dados-gerais'].foh.email && (
              <div className="ml-4 text-sm">Email: {riderData['dados-gerais'].foh.email}</div>
            )}
          </div>
        )}
        {riderData['dados-gerais']?.mon?.nome && (
          <div className="mb-4">
            <span className="font-bold text-sm">MON:</span>
            <span className="ml-2 text-sm">{riderData['dados-gerais'].mon.nome}</span>
            {riderData['dados-gerais'].mon.telefone && (
              <div className="ml-4 text-sm">Tel: {riderData['dados-gerais'].mon.telefone}</div>
            )}
            {riderData['dados-gerais'].mon.email && (
              <div className="ml-4 text-sm">Email: {riderData['dados-gerais'].mon.email}</div>
            )}
          </div>
        )}
      </div>

      {/* Rodapé */}
      <div className="absolute bottom-8 left-0 right-0 text-center">
        {exportOptions.customFooter?.trim() ? (
          <p className="text-xs text-gray-500">{exportOptions.customFooter.trim()}</p>
        ) : (
          <>
            <p className="text-xs text-gray-500">Gerado com</p>
            <p className="text-xs font-bold text-gray-500">Rider Forge</p>
          </>
        )}
      </div>
    </div>
  )

  const renderPA = () => {
    const pa = riderData.pa || {}
    const perf = pa.generalRequirements?.performance
    return (
    <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
        <SectionTitle>PA SYSTEM</SectionTitle>

        <div className="space-y-4 text-sm">
          {pa.mainSystem?.acceptedSystems?.length > 0 ? (
            <div>
              <h3 className="font-bold text-gray-700 mb-2">Sistema Principal:</h3>
              <ul className="list-disc ml-6 space-y-1">
                {pa.mainSystem.acceptedSystems.map((system, idx) => (
                  <li key={idx} className="text-black">{system}</li>
                ))}
              </ul>
            </div>
          ) : null}

          {pa.subwoofers?.required ? (
            <div>
              <h3 className="font-bold text-gray-700 mb-2">Subwoofers:</h3>
              {pa.subwoofers.crossoverEnabled && (
                <p className="text-black ml-2">Crossover: {pa.subwoofers.crossoverFrequency}Hz</p>
              )}
              {pa.subwoofers.notes && (
                <p className="text-gray-600 italic ml-2">Obs: {pa.subwoofers.notes}</p>
              )}
            </div>
          ) : null}

          {pa.frontFillRequired ? (
            <div>
              <h3 className="font-bold text-gray-700 mb-2">Front Fill:</h3>
              <p className="text-black ml-2">Requerido</p>
              {pa.frontFillCoverage && <p className="text-black ml-2">Cobertura: {pa.frontFillCoverage}</p>}
              {pa.frontFillNotes && <p className="text-gray-600 italic ml-2">Obs: {pa.frontFillNotes}</p>}
            </div>
          ) : null}

          {perf ? (
            <div>
              <h3 className="font-bold text-gray-700 mb-2">Especificações de Performance:</h3>
              <div className="ml-2 space-y-1">
                {perf.splAtFOH && (
                  <p className="text-black">• SPL no FOH: {perf.splAtFOH} {perf.splUnit || 'dB(A)'}</p>
                )}
                {perf.uniformity && (
                  <p className="text-black">• Uniformidade: {perf.uniformity} {perf.uniformityUnit || 'dB'}</p>
                )}
                {perf.frequencyResponse && (
                  <p className="text-black">
                    • Resposta de Frequência: {perf.frequencyResponse.low}-{perf.frequencyResponse.high} {perf.frequencyResponse.unit || 'Hz'}
                  </p>
                )}
                {perf.phaseAlignment && (
                  <p className="text-black font-semibold">• Sistemas alinhados em fase</p>
                )}
                {perf.noiseFree && (
                  <p className="text-black font-semibold">• Sistemas isentos de ruído</p>
                )}
              </div>
            </div>
          ) : null}

          {pa.generalRequirements?.systemConfig ? (
            <div>
              <h3 className="font-bold text-gray-700 mb-2">Configuração do Sistema:</h3>
              <div className="ml-2 space-y-1">
                {pa.generalRequirements.systemConfig.lineArrayRequired && (
                  <p className="text-black font-semibold">• Sistema Line Array (OBRIGATÓRIO)</p>
                )}
                {pa.generalRequirements.systemConfig.suspensionRequired && (
                  <p className="text-black font-semibold">• Sistema sempre suspenso (OBRIGATÓRIO)</p>
                )}
                {pa.generalRequirements.systemConfig.towerMounting && (
                  <p className="text-black font-semibold">• Montagem em torres layer (IMPRESCINDÍVEL)</p>
                )}
              </div>
            </div>
          ) : null}

          {pa.observacoes ? (
            <div>
              <h3 className="font-bold text-gray-700 mb-2">Observações Gerais:</h3>
              <p className="text-black ml-2 whitespace-pre-wrap">{pa.observacoes}</p>
            </div>
          ) : null}

          {!pa.mainSystem?.acceptedSystems?.length && !pa.subwoofers?.required && !pa.frontFillRequired && !pa.observacoes && !perf && (
            <p className="italic text-gray-500">Nenhum equipamento PA especificado</p>
          )}
        </div>

        <div className="absolute bottom-4 left-0 right-0 flex justify-between text-xs text-gray-500">
          <span>Rider Forge</span>
          <span>Página {currentPage} de {totalPages}</span>
        </div>
      </div>
    )
  }

  const renderConsolas = () => {
    const consolas = riderData.consolas || {}
    const foh = consolas.foh
    const mon = consolas.mon
    return (
      <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
        <SectionTitle>CONSOLAS</SectionTitle>
        <div className="space-y-6 text-sm">
          <div>
            <h3 className="font-bold text-gray-700 mb-2">FOH (Front of House)</h3>
            {foh?.consolaPreferida?.marca ? (
              <div className="ml-2">
                <p className="text-black">Consola Preferida: {foh.consolaPreferida.marca} {foh.consolaPreferida.modelo}</p>
                {foh.consolaPreferida.observacoes && (
                  <p className="text-gray-600 italic">Notas: {foh.consolaPreferida.observacoes}</p>
                )}
              </div>
            ) : null}
            {foh?.outrasConsolas?.length > 0 && (
              <div className="ml-2 mt-2">
                <p className="font-medium text-black">Outras Consolas Aceites:</p>
                <ul className="list-disc ml-6 space-y-1">
                  {foh.outrasConsolas.map((c, i) => (
                    <li key={i} className="text-black">{c.marca} {c.modelo}{c.observacoes ? ` — ${c.observacoes}` : ''}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div>
            <h3 className="font-bold text-gray-700 mb-2">MON (Monitor)</h3>
            {mon?.consolaPreferida?.marca ? (
              <div className="ml-2">
                <p className="text-black">Consola Preferida: {mon.consolaPreferida.marca} {mon.consolaPreferida.modelo}</p>
                {mon.consolaPreferida.observacoes && (
                  <p className="text-gray-600 italic">Notas: {mon.consolaPreferida.observacoes}</p>
                )}
              </div>
            ) : null}
            {mon?.outrasConsolas?.length > 0 && (
              <div className="ml-2 mt-2">
                <p className="font-medium text-black">Outras Consolas Aceites:</p>
                <ul className="list-disc ml-6 space-y-1">
                  {mon.outrasConsolas.map((c, i) => (
                    <li key={i} className="text-black">{c.marca} {c.modelo}{c.observacoes ? ` — ${c.observacoes}` : ''}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {!foh?.consolaPreferida?.marca && !mon?.consolaPreferida?.marca && (!foh?.outrasConsolas?.length && !mon?.outrasConsolas?.length) && (
            <p className="italic text-gray-500">Nenhuma consola especificada</p>
          )}
        </div>

        <div className="absolute bottom-4 left-0 right-0 flex justify-between text-xs text-gray-500">
          <span>Rider Forge</span>
          <span>Página {currentPage} de {totalPages}</span>
        </div>
      </div>
    )
  }

  const renderSistemasEscuta = () => {
    const se = riderData['sistemas-escuta'] || {}
    const hasContent = (
      (se.iems && parseInt(se.iems.quantidade) > 0) ||
      (se.sideFills && parseInt(se.sideFills.quantidade) > 0) ||
      (se.wedges && parseInt(se.wedges.quantidade) > 0) ||
      (se.subs && se.subs.length > 0)
    )
    return (
      <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
        <SectionTitle>SISTEMAS DE ESCUTA</SectionTitle>
        <div className="space-y-4 text-sm">
          {se.iems?.quantidade && parseInt(se.iems.quantidade) > 0 && (
            <div>
              <h3 className="font-bold text-gray-700 mb-1">IEMs:</h3>
              <p className="text-black ml-2">{se.iems.quantidade}x {se.iems.modeloPreferido || 'IEMs'}</p>
              {se.iems.observacoes && <p className="text-gray-600 italic ml-2">Obs: {se.iems.observacoes}</p>}
            </div>
          )}
          {se.sideFills?.quantidade && parseInt(se.sideFills.quantidade) > 0 && (
            <div>
              <h3 className="font-bold text-gray-700 mb-1">Side Fills:</h3>
              <p className="text-black ml-2">{se.sideFills.quantidade}x {se.sideFills.modelo || 'Side Fills'}</p>
              {se.sideFills.observacoes && <p className="text-gray-600 italic ml-2">Obs: {se.sideFills.observacoes}</p>}
            </div>
          )}
          {se.wedges?.quantidade && parseInt(se.wedges.quantidade) > 0 && (
            <div>
              <h3 className="font-bold text-gray-700 mb-1">Wedges:</h3>
              <p className="text-black ml-2">{se.wedges.quantidade}x {se.wedges.modelo || 'Wedges'}</p>
              {se.wedges.observacoes && <p className="text-gray-600 italic ml-2">Obs: {se.wedges.observacoes}</p>}
            </div>
          )}
          {se.subs?.length > 0 && (
            <div>
              <h3 className="font-bold text-gray-700 mb-1">Subs:</h3>
              <ul className="list-disc ml-6 space-y-1">
                {se.subs.map((sub) => (
                  <li key={sub.id} className="text-black">
                    {sub.quantidade}x {sub.modelo || 'Subs'}{sub.paraInstrumento ? ` (para ${sub.paraInstrumento})` : ''}
                    {sub.observacoes ? ` — ${sub.observacoes}` : ''}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {!hasContent && <p className="italic text-gray-500">Nenhum sistema de escuta especificado</p>}
        </div>

        <div className="absolute bottom-4 left-0 right-0 flex justify-between text-xs text-gray-500">
          <span>Rider Forge</span>
          <span>Página {currentPage} de {totalPages}</span>
        </div>
      </div>
    )
  }

  const renderEquipamentoAuxiliar = () => {
    const ea = riderData['equipamento-auxiliar'] || {}
    const hasContent = (
      (ea.talkbacks?.quantidade && parseInt(ea.talkbacks.quantidade) > 0) ||
      (ea.intercom?.quantidade && parseInt(ea.intercom.quantidade) > 0) ||
      ea.comunicacaoFohMon?.tipo ||
      ea.observacoes
    )
    return (
      <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
        <SectionTitle>EQUIPAMENTO AUXILIAR</SectionTitle>
        <div className="space-y-4 text-sm">
          {ea.talkbacks?.quantidade && parseInt(ea.talkbacks.quantidade) > 0 && (
            <div>
              <h3 className="font-bold text-gray-700 mb-1">Talkbacks:</h3>
              <p className="text-black ml-2">{ea.talkbacks.quantidade}x {ea.talkbacks.modelo || 'Talkbacks'}</p>
              {ea.talkbacks.observacoes && <p className="text-gray-600 italic ml-2">Obs: {ea.talkbacks.observacoes}</p>}
            </div>
          )}
          {ea.intercom?.quantidade && parseInt(ea.intercom.quantidade) > 0 && (
            <div>
              <h3 className="font-bold text-gray-700 mb-1">Intercom:</h3>
              <p className="text-black ml-2">{ea.intercom.quantidade}x {ea.intercom.modelo || 'Intercom'}</p>
              {ea.intercom.observacoes && <p className="text-gray-600 italic ml-2">Obs: {ea.intercom.observacoes}</p>}
            </div>
          )}
          {ea.comunicacaoFohMon?.tipo && (
            <div>
              <h3 className="font-bold text-gray-700 mb-1">Comunicação FOH/MON:</h3>
              <p className="text-black ml-2">Tipo: {ea.comunicacaoFohMon.tipo}</p>
              {ea.comunicacaoFohMon.observacoes && <p className="text-gray-600 italic ml-2">Obs: {ea.comunicacaoFohMon.observacoes}</p>}
            </div>
          )}
          {ea.observacoes && (
            <div>
              <h3 className="font-bold text-gray-700 mb-1">Observações Gerais:</h3>
              <p className="text-black ml-2 whitespace-pre-wrap">{ea.observacoes}</p>
            </div>
          )}
          {!hasContent && <p className="italic text-gray-500">Nenhum equipamento auxiliar especificado</p>}
        </div>

        <div className="absolute bottom-4 left-0 right-0 flex justify-between text-xs text-gray-500">
          <span>Rider Forge</span>
          <span>Página {currentPage} de {totalPages}</span>
        </div>
      </div>
    )
  }

  const renderMonitorMixes = () => {
    const mixes = riderData['monitor-mixes']?.mixes || []
    const tipoLabels = { 'iem': 'IEM', 'wedge': 'Wedge', 'sidefill': 'Side Fill' }
    const formatoLabels = { 'mono': 'Mono', 'stereo': 'Stereo' }
    const getMixNumber = (mixes, index) => {
      let channelNumber = 1
      for (let i = 0; i < index; i++) {
        channelNumber += mixes[i]?.formato === 'stereo' ? 2 : 1
      }
      if (mixes[index]?.formato === 'stereo') {
        const channel1 = channelNumber
        const channel2 = channelNumber + 1
        return `${channel1}/${channel2}`
      }
      return `${channelNumber}`
    }

    return (
      <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
        <SectionTitle>MONITOR MIXES</SectionTitle>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: themeStyles.tableHeaderBg }}>
                <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Mix</th>
                <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Instrumento/Músico</th>
                <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Tipo</th>
                <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Formato</th>
              </tr>
            </thead>
            <tbody>
              {mixes.length > 0 ? (
                mixes.map((mix, index) => (
                  <tr key={mix.id} className={index % 2 === 0 ? 'bg-gray-50' : ''}>
                    <td className="py-2 px-2">{getMixNumber(mixes, index)}</td>
                    <td className="py-2 px-2">{mix.instrumentoMusico || ''}</td>
                    <td className="py-2 px-2">{tipoLabels[mix.tipo] || mix.tipo || ''}</td>
                    <td className="py-2 px-2">{formatoLabels[mix.formato] || mix.formato || ''}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="py-4 text-center italic text-gray-500">
                    Nenhum mix configurado
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="absolute bottom-4 left-0 right-0 flex justify-between text-xs text-gray-500">
          <span>Rider Forge</span>
          <span>Página {currentPage} de {totalPages}</span>
        </div>
      </div>
    )
  }

  const renderInputList = () => (
    <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
      <SectionTitle>INPUT LIST</SectionTitle>
      
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: themeStyles.tableHeaderBg }}>
              <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Canal</th>
              <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Fonte</th>
              <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Micro/DI</th>
              <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Stand</th>
              <th className="text-left py-2 px-2 font-bold" style={{ color: themeStyles.tableHeaderText }}>Phantom</th>
            </tr>
          </thead>
          <tbody>
            {riderData['input-list']?.inputs?.length > 0 ? (
              riderData['input-list'].inputs.map((input, index) => (
                <tr key={input.id} className={index % 2 === 0 ? 'bg-gray-50' : ''}>
                  <td className="py-2 px-2">{input.canal || ''}</td>
                  <td className="py-2 px-2">{input.fonte || ''}</td>
                  <td className="py-2 px-2">{input.microDi || ''}</td>
                  <td className="py-2 px-2">{input.stand || ''}</td>
                  <td className="py-2 px-2">{input.phantom ? 'Sim' : 'Não'}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="py-4 text-center italic text-gray-500">
                  Nenhum equipamento especificado
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Rodapé */}
      <div className="absolute bottom-4 left-0 right-0 flex justify-between text-xs text-gray-500">
        <span>Rider Forge</span>
        <span>Página {currentPage} de {totalPages}</span>
      </div>
    </div>
  )



  const renderObservacoes = () => (
    <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
      <SectionTitle>OBSERVAÇÕES FINAIS</SectionTitle>
      
      <div className="text-sm leading-relaxed">
        {riderData['observacoes-finais']?.observacoes ? (
          <p className="whitespace-pre-wrap">{riderData['observacoes-finais'].observacoes}</p>
        ) : (
          <p className="italic text-gray-500">Nenhum equipamento especificado</p>
        )}
      </div>

      {/* Rodapé */}
      <div className="absolute bottom-4 left-0 right-0 flex justify-between text-xs text-gray-500">
        <span>Rider Forge</span>
        <span>Página {currentPage} de {totalPages}</span>
      </div>
    </div>
  )

  const renderStagePlot = () => (
    <div className="pdf-page bg-white text-black p-8 min-h-[297mm] relative">
      <h2 className="text-xl font-bold text-gray-700 mb-6">STAGE PLOT</h2>
      {riderData['dados-gerais']?.stagePlot?.data ? (
        <img src={riderData['dados-gerais'].stagePlot.data} alt="Stage Plot" className="w-full max-h-[230mm] object-contain border border-gray-300" />
      ) : (
        <p className="text-sm italic text-gray-500">Sem stage plot</p>
      )}
      <div className="absolute bottom-4 left-0 right-0 flex justify-between text-xs text-gray-500">
        <span>Rider Forge</span>
        <span>Página {currentPage} de {totalPages}</span>
      </div>
    </div>
  )

  // Build pages to mirror compact vs non-compact layout
  const totalPages = 8 + (hasStagePlot ? 1 : 0)

  const getPageTitle = (page) => {
    if (hasStagePlot) {
      switch (page) {
        case 1: return 'Capa'
        case 2: return 'PA'
        case 3: return 'Consolas'
        case 4: return 'Sistemas de Escuta'
        case 5: return 'Equipamento Auxiliar'
        case 6: return 'Input List'
        case 7: return 'Monitor Mixes'
        case 8: return 'Observações Finais'
        case 9: return 'Stage Plot'
        default: return 'Capa'
      }
    }
    switch (page) {
      case 1: return 'Capa'
      case 2: return 'PA'
      case 3: return 'Consolas'
      case 4: return 'Sistemas de Escuta'
      case 5: return 'Equipamento Auxiliar'
      case 6: return 'Input List'
      case 7: return 'Monitor Mixes'
      case 8: return 'Observações Finais'
      default: return 'Capa'
    }
  }

  const getPageContent = () => {
    if (hasStagePlot) {
      switch (currentPage) {
        case 1: return renderCapa()
        case 2: return renderPA()
        case 3: return renderConsolas()
        case 4: return renderSistemasEscuta()
        case 5: return renderEquipamentoAuxiliar()
        case 6: return renderInputList()
        case 7: return renderMonitorMixes()
        case 8: return renderObservacoes()
        case 9: return renderStagePlot()
        default: return renderCapa()
      }
    }
    switch (currentPage) {
      case 1: return renderCapa()
      case 2: return renderPA()
      case 3: return renderConsolas()
      case 4: return renderSistemasEscuta()
      case 5: return renderEquipamentoAuxiliar()
      case 6: return renderInputList()
      case 7: return renderMonitorMixes()
      case 8: return renderObservacoes()
      default: return renderCapa()
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-dark-800 rounded-lg max-w-4xl w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-dark-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-gray-100">Preview do PDF</h3>
              <p className="text-gray-400 text-sm">Visualização do rider técnico</p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-200 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Navigation */}
        <div className="px-6 py-4 bg-dark-700 border-b border-dark-600">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="btn-secondary text-sm disabled:opacity-50"
              >
                ← Anterior
              </button>
              <div className="text-center">
                <span className="text-gray-300 text-sm block">
                  Página {currentPage} de {totalPages}
                </span>
                <span className="text-gray-400 text-xs">
                  {getPageTitle(currentPage)}
                </span>
              </div>
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="btn-secondary text-sm disabled:opacity-50"
              >
                Próximo →
              </button>
            </div>
            <div className="flex gap-2">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`preview-page-button ${
                    currentPage === page ? 'active' : ''
                  }`}
                  title={getPageTitle(page)}
                >
                  {page}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* PDF Preview */}
        <div className="flex-1 overflow-auto p-6">
          <div className="flex justify-center">
            <div className="shadow-2xl border border-gray-300">
              {getPageContent()}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-dark-700">
          <div className="flex justify-end gap-3">
            <button
              onClick={onClose}
              className="btn-secondary"
            >
              Cancelar
            </button>
            <button
              onClick={onExport}
              className="btn-primary flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Exportar PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PDFPreview
