import { useState, useEffect } from 'react'
import { processPDFRider, testPDFFile } from '../utils/pdfProcessor'

function PDFImportPreview({ file, onConfirm, onCancel, onError }) {
  const [extractedData, setExtractedData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [riderName, setRiderName] = useState('')

  useEffect(() => {
    const processFile = async () => {
      try {
        setLoading(true)
        setError(null)
        
        // Primeiro, testar o PDF
        console.log('Testando PDF antes do processamento...')
        const testResult = await testPDFFile(file)
        console.log('Resultado do teste:', testResult)
        
        if (!testResult.isValid) {
          throw new Error(`PDF inválido: ${testResult.issues.join(', ')}`)
        }
        
        if (!testResult.canExtractText) {
          throw new Error(`Não é possível extrair texto do PDF: ${testResult.issues.join(', ')}`)
        }
        
        if (testResult.textLength === 0) {
          throw new Error('O PDF não contém texto extraível.')
        }
        
        console.log(`PDF válido: ${testResult.pages} páginas, ${testResult.textLength} caracteres`)
        
        // Processar o PDF
        const data = await processPDFRider(file)
        setExtractedData(data)
        setRiderName(data.name)
      } catch (err) {
        console.error('Erro no processamento:', err)
        setError(err.message)
        onError?.(err.message)
      } finally {
        setLoading(false)
      }
    }

    if (file) {
      processFile()
    }
  }, [file, onError])

  const handleConfirm = () => {
    if (extractedData) {
      onConfirm({
        ...extractedData,
        name: riderName
      })
    }
  }

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent-blue mx-auto mb-4"></div>
        <p className="text-gray-300">A processar PDF...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <div className="w-16 h-16 bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
        </div>
        <h3 className="text-lg font-semibold text-red-300 mb-2">Erro ao processar PDF</h3>
        <p className="text-gray-400 mb-4">{error}</p>
        
        {/* Informações adicionais de ajuda */}
        <div className="bg-dark-800 rounded-lg p-4 mb-4 text-left">
          <h4 className="font-medium text-gray-200 mb-2">Possíveis soluções:</h4>
          <ul className="text-sm text-gray-400 space-y-1">
            <li>• Verifique se o PDF contém texto selecionável</li>
            <li>• Tente com um PDF criado digitalmente (não digitalizado)</li>
            <li>• Certifique-se de que o PDF não está protegido com senha</li>
            <li>• Verifique se o arquivo não está corrompido</li>
            <li>• Tente com um PDF menor (máximo 50MB)</li>
          </ul>
        </div>
        
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 btn-secondary"
          >
            Voltar
          </button>
          <button
            onClick={() => window.open('https://www.adobe.com/acrobat/online/pdf-to-text.html', '_blank')}
            className="flex-1 btn-primary"
          >
            Converter PDF
          </button>
        </div>
      </div>
    )
  }

  if (!extractedData) {
    return null
  }

  const sections = Object.keys(extractedData.data).filter(key => 
    Object.keys(extractedData.data[key]).length > 0
  )

  return (
    <div className="space-y-6">
      {/* Nome do Rider */}
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Nome do Rider
        </label>
        <input
          type="text"
          value={riderName}
          onChange={(e) => setRiderName(e.target.value)}
          className="w-full px-3 py-2 bg-dark-800 border border-dark-600 rounded-lg text-gray-100 focus:border-accent-blue focus:outline-none"
          placeholder="Nome do rider"
        />
      </div>

      {/* Preview dos dados extraídos */}
      <div>
        <h4 className="text-sm font-medium text-gray-300 mb-3">Dados extraídos do PDF:</h4>
        
        {sections.length === 0 ? (
          <div className="text-center py-4 text-gray-400">
            <p>Nenhum dado estruturado foi encontrado no PDF.</p>
            <p className="text-sm mt-1">O rider será importado como um documento vazio.</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {sections.map((section) => {
              const sectionData = extractedData.data[section]
              const sectionName = getSectionDisplayName(section)
              const itemCount = getItemCount(sectionData)
              
              return (
                <div key={section} className="p-3 bg-dark-800 rounded-lg border border-dark-600">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium text-gray-200">{sectionName}</h5>
                    <span className="text-xs text-gray-400 bg-dark-700 px-2 py-1 rounded">
                      {itemCount} {itemCount === 1 ? 'item' : 'itens'}
                    </span>
                  </div>
                  
                  <div className="text-sm text-gray-400">
                    {renderSectionPreview(section, sectionData)}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Botões */}
      <div className="flex gap-3 pt-4">
        <button
          onClick={onCancel}
          className="flex-1 btn-secondary"
        >
          Cancelar
        </button>
        <button
          onClick={handleConfirm}
          className="flex-1 btn-primary"
        >
          Importar Rider
        </button>
      </div>
    </div>
  )
}

function getSectionDisplayName(section) {
  const names = {
    'dados-gerais': 'Dados Gerais',
    'pa': 'Sistema PA',
    'consolas': 'Consolas',
    'sistemas-escuta': 'Sistemas de Escuta',
    'equipamento-auxiliar': 'Equipamento Auxiliar',
    'input-list': 'Lista de Inputs',
    'monitor-mixes': 'Monitor Mixes',
    'observacoes-finais': 'Observações Finais'
  }
  return names[section] || section
}

function getItemCount(data) {
  if (Array.isArray(data)) return data.length
  if (data.inputs) return data.inputs.length
  if (data.mixes) return data.mixes.length
  if (data.observacoes) return data.observacoes.length
  if (data.sistema) return data.sistema.length
  if (data.consola) return data.consola.length
  if (data.equipamento) return data.equipamento.length
  return Object.keys(data).length
}

function renderSectionPreview(section, data) {
  switch (section) {
    case 'dados-gerais':
      return (
        <div className="space-y-1">
          {data.artista && <div>Artista: {data.artista}</div>}
          {data.local && <div>Local: {data.local}</div>}
          {data.data && <div>Data: {data.data}</div>}
          {data.hora && <div>Hora: {data.hora}</div>}
        </div>
      )
    
    case 'input-list':
      if (data.inputs && data.inputs.length > 0) {
        return (
          <div>
            {data.inputs.slice(0, 3).map((input, index) => (
              <div key={index} className="mb-1">
                {input.numero && `${input.numero}. `}
                {input.instrumento || 'Instrumento não especificado'}
              </div>
            ))}
            {data.inputs.length > 3 && (
              <div className="text-xs text-gray-500">
                +{data.inputs.length - 3} mais inputs...
              </div>
            )}
          </div>
        )
      }
      return <div>Nenhum input encontrado</div>
    
    case 'monitor-mixes':
      if (data.mixes && data.mixes.length > 0) {
        return (
          <div>
            {data.mixes.slice(0, 3).map((mix, index) => (
              <div key={index} className="mb-1">
                {mix.numero && `Mix ${mix.numero}: `}
                {mix.instrumento || 'Instrumento não especificado'}
              </div>
            ))}
            {data.mixes.length > 3 && (
              <div className="text-xs text-gray-500">
                +{data.mixes.length - 3} mais mixes...
              </div>
            )}
          </div>
        )
      }
      return <div>Nenhum mix encontrado</div>
    
    case 'observacoes-finais':
      if (data.observacoes && data.observacoes.length > 0) {
        return (
          <div>
            {data.observacoes.slice(0, 2).map((obs, index) => (
              <div key={index} className="mb-1">• {obs}</div>
            ))}
            {data.observacoes.length > 2 && (
              <div className="text-xs text-gray-500">
                +{data.observacoes.length - 2} mais observações...
              </div>
            )}
          </div>
        )
      }
      return <div>Nenhuma observação encontrada</div>
    
    default:
      // Para outras seções, mostrar arrays ou objetos simples
      if (Array.isArray(data)) {
        return (
          <div>
            {data.slice(0, 3).map((item, index) => (
              <div key={index} className="mb-1">• {item}</div>
            ))}
            {data.length > 3 && (
              <div className="text-xs text-gray-500">
                +{data.length - 3} mais itens...
              </div>
            )}
          </div>
        )
      }
      
      const items = Object.entries(data).slice(0, 3)
      return (
        <div>
          {items.map(([key, value], index) => (
            <div key={index} className="mb-1">
              {key}: {Array.isArray(value) ? `${value.length} itens` : value}
            </div>
          ))}
          {Object.keys(data).length > 3 && (
            <div className="text-xs text-gray-500">
              +{Object.keys(data).length - 3} mais campos...
            </div>
          )}
        </div>
      )
  }
}

export default PDFImportPreview
