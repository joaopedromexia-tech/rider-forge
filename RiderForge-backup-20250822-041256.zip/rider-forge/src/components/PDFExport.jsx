import { useRef, useState, useEffect } from 'react'
import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import PDFPreview from './PDFPreview'
import { useProFeatures } from '../hooks/useProFeatures'
import ProUpgradeModal from './ProUpgradeModal'

function PDFExport({ isOpen, riderData, riderName, onClose }) {
  const [isGenerating, setIsGenerating] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [exportOptions, setExportOptions] = useState({ includeStagePlot: true, customFooter: '', theme: 'base', compactLayout: true })
  const pdfRef = useRef(null)
  
  const {
    showUpgradeModal,
    currentFeature,
    closeUpgradeModal,
    useProFeature,
    PRO_FEATURES
  } = useProFeatures()

  const formatDate = (dateString) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    return date.toLocaleDateString('pt-PT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  }

  // Load export options
  useEffect(() => {
    try {
      const stored = localStorage.getItem('riderForge_exportOptions')
      if (stored) {
        setExportOptions(prev => ({ ...prev, ...JSON.parse(stored) }))
      }
    } catch (_) {}
  }, [])

  // Persist export options
  useEffect(() => {
    try {
      localStorage.setItem('riderForge_exportOptions', JSON.stringify(exportOptions))
    } catch (_) {}
  }, [exportOptions])

  const generatePDF = async () => {
    setIsGenerating(true)
    
    try {
      console.log('[PDFExport] generatePDF riderData:', riderData)
      const pdf = new jsPDF('p', 'mm', 'a4')
      const pageWidth = pdf.internal.pageSize.getWidth()
      const pageHeight = pdf.internal.pageSize.getHeight()
      const margin = 20
      const contentWidth = pageWidth - (margin * 2)
      
             let currentY = margin
       let pageNumber = 1
       const hasStagePlot = Boolean(riderData['dados-gerais']?.stagePlot?.data) && exportOptions.includeStagePlot
       const totalPages = 8 + (hasStagePlot ? 1 : 0)

      // Theme styles
      const theme = (exportOptions?.theme || 'base')
      const getTheme = (t) => {
        if (t === 'pro_modern') {
          return {
            titleFontSize: 24,
            subtitleFontSize: 12,
            sectionFontSize: 13,
            subsectionFontSize: 11,
            bodyFontSize: 9,
            smallFontSize: 8,
            sectionTitleBg: [244, 246, 248],
            sectionTitleText: [40, 40, 40],
            tableHeaderFill: [238, 242, 255],
            tableHeaderText: [60, 60, 60],
            separatorColor: [220, 220, 220],
            separatorThickness: 0.2,
            sectionTopSpacing: 10,
            compactSectionSpacing: 8
          }
        }
        if (t === 'pro_minimal') {
          return {
            titleFontSize: 22,
            subtitleFontSize: 11,
            sectionFontSize: 12,
            subsectionFontSize: 10,
            bodyFontSize: 9,
            smallFontSize: 8,
            sectionTitleBg: null,
            sectionTitleText: [30, 30, 30],
            tableHeaderFill: null,
            tableHeaderText: [70, 70, 70],
            separatorColor: [230, 230, 230],
            separatorThickness: 0.2,
            sectionTopSpacing: 8,
            compactSectionSpacing: 6
          }
        }
        // base
        return {
          titleFontSize: 24,
          subtitleFontSize: 12,
          sectionFontSize: 14,
          subsectionFontSize: 12,
          bodyFontSize: 10,
          smallFontSize: 8,
          sectionTitleBg: null,
          sectionTitleText: [50, 50, 50],
          tableHeaderFill: [240, 240, 240],
          tableHeaderText: [100, 100, 100],
          separatorColor: [220, 220, 220],
          separatorThickness: 0.2,
          sectionTopSpacing: 12,
          compactSectionSpacing: 8
        }
      }
      const themeStyles = getTheme(theme)

      // Utility: separator between compact sections
      const drawSeparator = () => {
        if (!exportOptions?.compactLayout) return
        pdf.setDrawColor(...themeStyles.separatorColor)
        pdf.setLineWidth(themeStyles.separatorThickness)
        const sepY = currentY - 6
        if (sepY > margin + 10) {
          pdf.line(margin, sepY, pageWidth - margin, sepY)
        }
      }
 
      // Configurações de estilo
      const titleFontSize = themeStyles.titleFontSize
      const subtitleFontSize = themeStyles.subtitleFontSize
      const sectionFontSize = themeStyles.sectionFontSize
      const subsectionFontSize = themeStyles.subsectionFontSize
      const bodyFontSize = themeStyles.bodyFontSize
      const smallFontSize = themeStyles.smallFontSize

      // Helpers
      const drawPageHeader = (sectionTitle) => {
        const artista = riderData['dados-gerais']?.artista || 'Artista'
        pdf.setFontSize(8)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(120, 120, 120)
        // Left: Artist
        pdf.text(artista, margin, 12)
        // Center: Rider Técnico
        pdf.text('Rider Técnico', pageWidth / 2, 12, { align: 'center' })
        // Right: Section
        if (sectionTitle) {
          pdf.text(sectionTitle, pageWidth - margin, 12, { align: 'right' })
        }
        // Divider
        pdf.setDrawColor(220, 220, 220)
        pdf.setLineWidth(0.2)
        pdf.line(margin, 14, pageWidth - margin, 14)
      }

      const drawFooter = () => {
        const y = pageHeight - 20
        pdf.setFontSize(8)
        pdf.setTextColor(100, 100, 100)
        pdf.text(`Página ${pageNumber}` , pageWidth - margin, y, { align: 'right' })
        pdf.text('Rider Forge', margin, y)
        if (exportOptions?.customFooter && exportOptions.customFooter.trim()) {
          pdf.text(exportOptions.customFooter.trim(), pageWidth / 2, y, { align: 'center' })
        }
      }

      // Ensure there's space left, add page if needed
      const ensureSpace = (requiredHeight = 20, sectionTitleForHeader) => {
        if (currentY + requiredHeight > pageHeight - 28) {
          pdf.addPage()
          pageNumber++
          currentY = margin
          if (sectionTitleForHeader) drawPageHeader(sectionTitleForHeader)
        }
      }

      const clampText = (text, maxChars = 32) => {
        if (!text) return ''
        const s = String(text)
        return s.length > maxChars ? s.slice(0, maxChars - 1) + '…' : s
      }

      // Generic table renderer with wrapping and header repeat
      const drawTable = ({
        sectionTitle,
        columns,
        rows,
        startY,
        headerFill,
        headerTextColor
      }) => {
        const headerHeight = 8
        let y = startY

        const drawHeader = () => {
          pdf.setFontSize(bodyFontSize)
          pdf.setFont('helvetica', 'bold')
          if (headerFill) {
            pdf.setFillColor(...headerFill)
            pdf.rect(margin, y - 5, contentWidth, headerHeight, 'F')
          }
          pdf.setTextColor(...(headerTextColor || [100, 100, 100]))
          let x = margin
          columns.forEach(col => {
            pdf.text(col.label, x + 5, y)
            x += col.width
          })
          y += 10
        }

        const drawRow = (row, rowIndex) => {
          pdf.setFontSize(bodyFontSize)
          pdf.setFont('helvetica', 'normal')
          pdf.setTextColor(0, 0, 0)

          // Wrap text per column
          const colLines = []
          const lineHeight = 6
          columns.forEach(col => {
            const value = col.getValue(row, rowIndex) || ''
            const maxWidth = col.width - 10
            const lines = pdf.splitTextToSize(String(value), maxWidth)
            colLines.push(lines)
          })
          const rowHeight = Math.max(...colLines.map(lines => lines.length)) * lineHeight + 2

          // Page break if needed
          if (y + rowHeight > pageHeight - 28) {
            pdf.addPage()
            pageNumber++
            y = margin
            drawPageHeader(sectionTitle)
            drawHeader()
          }

          // Zebra fill
          if (rowIndex % 2 === 0) {
            pdf.setFillColor(248, 248, 248)
            pdf.rect(margin, y - 3, contentWidth, rowHeight, 'F')
          }

          // Draw cell text
          let x = margin
          columns.forEach((col, i) => {
            const lines = colLines[i]
            let yy = y
            lines.forEach(line => {
              pdf.text(line, x + 5, yy)
              yy += lineHeight
            })
            x += col.width
          })

          y += rowHeight
          return y
        }

        // Ensure space and draw header
        ensureSpace(20, sectionTitle)
        drawHeader()
        rows.forEach((row, idx) => { y = drawRow(row, idx) })
        currentY = y
      }
 
              // PÁGINA 1 - CAPA
       // Título "RIDER TÉCNICO"
       pdf.setFontSize(18)
       pdf.setFont('helvetica', 'bold')
       pdf.setTextColor(100, 100, 100)
       pdf.text('RIDER TÉCNICO', pageWidth / 2, currentY + 20, { align: 'center' })
       
       currentY += 40
       
       // Nome do artista
       pdf.setFontSize(titleFontSize)
       pdf.setFont('helvetica', 'bold')
       pdf.setTextColor(0, 0, 0)
       const artista = riderData['dados-gerais']?.artista || 'Artista'
       pdf.text(artista, pageWidth / 2, currentY, { align: 'center' })
       
       currentY += 40
      
      // Versão do Rider e Ano da Tour
      pdf.setFontSize(subtitleFontSize)
      pdf.setFont('helvetica', 'normal')
      let infoText = ''
      if (riderData['dados-gerais']?.versaoRider) {
        infoText += `Versão ${riderData['dados-gerais'].versaoRider}`
      }
      if (riderData['dados-gerais']?.versaoRider && riderData['dados-gerais']?.anoTour) {
        infoText += ' • '
      }
      if (riderData['dados-gerais']?.anoTour) {
        infoText += `Tour ${riderData['dados-gerais'].anoTour}`
      }
      if (infoText) {
        pdf.text(infoText, pageWidth / 2, currentY, { align: 'center' })
      }
      
      currentY += 30
 
      // Imagem de Capa
      if (riderData['dados-gerais']?.imagemCapa?.data) {
        const img = riderData['dados-gerais'].imagemCapa
        const format = (img.type || '').toLowerCase().includes('png') ? 'PNG' : 'JPEG'
        const maxW = contentWidth
        const maxH = 70
        try {
          pdf.addImage(img.data, format, margin, currentY, maxW, maxH)
          currentY += maxH + 10
        } catch (_) {}
      }
      
              // Contactos principais
       pdf.setFontSize(bodyFontSize)
       pdf.setFont('helvetica', 'bold')
       pdf.setTextColor(50, 50, 50)
       pdf.text('CONTACTOS PRINCIPAIS', pageWidth / 2, currentY, { align: 'center' })
       
       currentY += 15
       
       pdf.setFont('helvetica', 'normal')
       pdf.setTextColor(0, 0, 0)
       
       if (riderData['dados-gerais']?.roadManager?.nome) {
         pdf.setFont('helvetica', 'bold')
         pdf.text('Road Manager:', margin + 20, currentY)
         pdf.setFont('helvetica', 'normal')
         pdf.text(riderData['dados-gerais'].roadManager.nome, margin + 60, currentY)
         currentY += 8
         
         if (riderData['dados-gerais'].roadManager.telefone) {
           pdf.text(`Tel: ${riderData['dados-gerais'].roadManager.telefone}`, margin + 60, currentY)
           currentY += 8
         }
         
         if (riderData['dados-gerais'].roadManager.email) {
           pdf.text(`Email: ${riderData['dados-gerais'].roadManager.email}`, margin + 60, currentY)
           currentY += 8
         }
         currentY += 5
       }
       
       if (riderData['dados-gerais']?.foh?.nome) {
         pdf.setFont('helvetica', 'bold')
         pdf.text('FOH:', margin + 20, currentY)
         pdf.setFont('helvetica', 'normal')
         pdf.text(riderData['dados-gerais'].foh.nome, margin + 60, currentY)
         currentY += 8
         
         if (riderData['dados-gerais'].foh.telefone) {
           pdf.text(`Tel: ${riderData['dados-gerais'].foh.telefone}`, margin + 60, currentY)
           currentY += 8
         }
         
         if (riderData['dados-gerais'].foh.email) {
           pdf.text(`Email: ${riderData['dados-gerais'].foh.email}`, margin + 60, currentY)
           currentY += 8
         }
         currentY += 5
       }
       
       if (riderData['dados-gerais']?.mon?.nome) {
         pdf.setFont('helvetica', 'bold')
         pdf.text('MON:', margin + 20, currentY)
         pdf.setFont('helvetica', 'normal')
         pdf.text(riderData['dados-gerais'].mon.nome, margin + 60, currentY)
         currentY += 8
         
         if (riderData['dados-gerais'].mon.telefone) {
           pdf.text(`Tel: ${riderData['dados-gerais'].mon.telefone}`, margin + 60, currentY)
           currentY += 8
         }
         
         if (riderData['dados-gerais'].mon.email) {
           pdf.text(`Email: ${riderData['dados-gerais'].mon.email}`, margin + 60, currentY)
           currentY += 8
         }
       }
      
              // Rodapé da capa
       currentY = pageHeight - 40
       pdf.setFontSize(smallFontSize)
       pdf.setTextColor(100, 100, 100)
       pdf.text('Gerado com', pageWidth / 2, currentY, { align: 'center' })
       currentY += 5
       pdf.setFont('helvetica', 'bold')
       pdf.text('Rider Forge', pageWidth / 2, currentY, { align: 'center' })
       
      // PÁGINA 2 - PA
      pdf.addPage()
      pageNumber++
      currentY = margin
      drawPageHeader('PA System')
      
      ensureSpace(24, 'PA System')
      pdf.setFontSize(sectionFontSize)
      pdf.setFont('helvetica', 'bold')
      if (themeStyles.sectionTitleBg) {
        pdf.setFillColor(...themeStyles.sectionTitleBg)
        pdf.rect(margin - 2, currentY - 6, contentWidth + 4, 10, 'F')
      }
      pdf.setTextColor(...themeStyles.sectionTitleText)
      pdf.text('PA SYSTEM', margin, currentY)
      
      currentY += themeStyles.sectionTopSpacing
      
      // Sistema Principal
      if (riderData.pa?.mainSystem?.acceptedSystems && riderData.pa.mainSystem.acceptedSystems.length > 0) {
        pdf.setFontSize(subsectionFontSize)
        pdf.setFont('helvetica', 'bold')
        pdf.setTextColor(50, 50, 50)
        pdf.text('Sistema Principal:', margin, currentY)
        currentY += 12
        
        riderData.pa.mainSystem.acceptedSystems.forEach((system, index) => {
          if (currentY > pageHeight - 40) {
            pdf.addPage()
            pageNumber++
            currentY = margin
          }
          
          pdf.setFontSize(bodyFontSize)
          pdf.setFont('helvetica', 'normal')
          pdf.setTextColor(0, 0, 0)
          pdf.text(`${index + 1}. ${system}`, margin + 10, currentY)
          currentY += 8
        })
        currentY += 5
      }
      
      // Subwoofers
      if (riderData.pa?.subwoofers?.required) {
        pdf.setFontSize(subsectionFontSize)
        pdf.setFont('helvetica', 'bold')
        pdf.setTextColor(50, 50, 50)
        pdf.text('Subwoofers:', margin, currentY)
        currentY += 12
        
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        
        if (riderData.pa.subwoofers.crossoverEnabled) {
          pdf.text(`Crossover: ${riderData.pa.subwoofers.crossoverFrequency}Hz`, margin + 10, currentY)
          currentY += 8
        }
        
        if (riderData.pa.subwoofers.notes) {
          pdf.setFontSize(smallFontSize)
          pdf.setTextColor(100, 100, 100)
          pdf.text(`Notas: ${riderData.pa.subwoofers.notes}`, margin + 10, currentY)
          currentY += 8
        }
        currentY += 5
      }
      
      // Front Fill
      if (riderData.pa?.frontFillRequired) {
        pdf.setFontSize(subsectionFontSize)
        pdf.setFont('helvetica', 'bold')
        pdf.setTextColor(50, 50, 50)
        pdf.text('Front Fill:', margin, currentY)
        currentY += 12
        
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        pdf.text('Requerido', margin + 10, currentY)
        currentY += 8
        
        if (riderData.pa.frontFillCoverage) {
          pdf.text(`Cobertura: ${riderData.pa.frontFillCoverage}`, margin + 10, currentY)
          currentY += 8
        }
        
        if (riderData.pa.frontFillNotes) {
          pdf.setFontSize(smallFontSize)
          pdf.setTextColor(100, 100, 100)
          pdf.text(`Notas: ${riderData.pa.frontFillNotes}`, margin + 10, currentY)
          currentY += 8
        }
        currentY += 5
      }
      
      // Requisitos de Performance
      if (riderData.pa?.generalRequirements?.performance) {
        const perf = riderData.pa.generalRequirements.performance
        pdf.setFontSize(subsectionFontSize)
        pdf.setFont('helvetica', 'bold')
        pdf.setTextColor(50, 50, 50)
        pdf.text('Especificações de Performance:', margin, currentY)
        currentY += 12
        
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        
        if (perf.splAtFOH) {
          pdf.text(`SPL no FOH: ${perf.splAtFOH} ${perf.splUnit || 'dB(A)'}`, margin + 10, currentY)
          currentY += 8
        }
        
        if (perf.uniformity) {
          pdf.text(`Uniformidade: ${perf.uniformity} ${perf.uniformityUnit || 'dB'}`, margin + 10, currentY)
          currentY += 8
        }
        
        if (perf.frequencyResponse) {
          pdf.text(`Resposta de Frequência: ${perf.frequencyResponse.low}-${perf.frequencyResponse.high} ${perf.frequencyResponse.unit || 'Hz'}`, margin + 10, currentY)
          currentY += 8
        }
        currentY += 5
      }
      
      // Observações Gerais
      if (riderData.pa?.observacoes) {
        pdf.setFontSize(subsectionFontSize)
        pdf.setFont('helvetica', 'bold')
        pdf.setTextColor(50, 50, 50)
        pdf.text('Observações Gerais:', margin, currentY)
        currentY += 12
        
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        const observacoes = riderData.pa.observacoes
        const lines = pdf.splitTextToSize(observacoes, contentWidth - 20)
        
        lines.forEach(line => {
          if (currentY > pageHeight - 40) {
            pdf.addPage()
            pageNumber++
            currentY = margin
          }
          
          pdf.text(line, margin + 10, currentY)
          currentY += 6
        })
      }
      
      // Se não há dados específicos, mostrar mensagem
      if (!riderData.pa || (!riderData.pa.mainSystem?.acceptedSystems?.length && !riderData.pa.subwoofers?.required && !riderData.pa.frontFillRequired && !riderData.pa.observacoes)) {
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'italic')
        pdf.setTextColor(100, 100, 100)
        pdf.text('Nenhum equipamento PA especificado', margin, currentY)
      }
      
      // Rodapé
      drawFooter()
      
      // CONSOLAS (nova página apenas se não for compacto)
      if (!exportOptions?.compactLayout) {
        pdf.addPage()
        pageNumber++
        currentY = margin
        drawPageHeader('Consolas')
      } else {
        currentY += 12
      }
       
      ensureSpace(24, 'Consolas')
      pdf.setFontSize(sectionFontSize)
      pdf.setFont('helvetica', 'bold')
      if (exportOptions?.compactLayout) { drawSeparator() }
      if (themeStyles.sectionTitleBg) {
        pdf.setFillColor(...themeStyles.sectionTitleBg)
        pdf.rect(margin - 2, currentY - 6, contentWidth + 4, 10, 'F')
      }
      pdf.setTextColor(...themeStyles.sectionTitleText)
      pdf.text('CONSOLAS', margin, currentY)
      
      currentY += themeStyles.sectionTopSpacing
      
      // FOH Section
      pdf.setFontSize(subsectionFontSize)
      pdf.setFont('helvetica', 'bold')
      pdf.setTextColor(50, 50, 50)
      pdf.text('FOH (Front of House):', margin, currentY)
      currentY += 12
      
      if (riderData.consolas?.foh?.consolaPreferida?.marca) {
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        pdf.text(`Consola Preferida: ${riderData.consolas.foh.consolaPreferida.marca} ${riderData.consolas.foh.consolaPreferida.modelo}`, margin, currentY)
        currentY += 8
        if (riderData.consolas.foh.consolaPreferida.observacoes) {
          pdf.setFontSize(smallFontSize)
          pdf.setTextColor(100, 100, 100)
          pdf.text(`   Notas: ${riderData.consolas.foh.consolaPreferida.observacoes}`, margin + 20, currentY)
          currentY += 8
        }
      }
      
      if (riderData.consolas?.foh?.outrasConsolas && riderData.consolas.foh.outrasConsolas.length > 0) {
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        pdf.text('Outras Consolas Aceites:', margin, currentY)
        currentY += 8
        riderData.consolas.foh.outrasConsolas.forEach((consola, index) => {
          pdf.text(`${index + 1}. ${consola.marca} ${consola.modelo}`, margin + 20, currentY)
          currentY += 8
          if (consola.observacoes) {
            pdf.setFontSize(smallFontSize)
            pdf.setTextColor(100, 100, 100)
            pdf.text(`   Notas: ${consola.observacoes}`, margin + 25, currentY)
            currentY += 8
          }
        })
      }
      
      currentY += 15
      
      // MON Section
      pdf.setFontSize(subsectionFontSize)
      pdf.setFont('helvetica', 'bold')
      pdf.setTextColor(50, 50, 50)
      pdf.text('MON (Monitor):', margin, currentY)
      currentY += 12
      
      if (riderData.consolas?.mon?.consolaPreferida?.marca) {
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        pdf.text(`Consola Preferida: ${riderData.consolas.mon.consolaPreferida.marca} ${riderData.consolas.mon.consolaPreferida.modelo}`, margin, currentY)
        currentY += 8
        if (riderData.consolas.mon.consolaPreferida.observacoes) {
          pdf.setFontSize(smallFontSize)
          pdf.setTextColor(100, 100, 100)
          pdf.text(`   Notas: ${riderData.consolas.mon.consolaPreferida.observacoes}`, margin + 20, currentY)
          currentY += 8
        }
      }
      
      if (riderData.consolas?.mon?.outrasConsolas && riderData.consolas.mon.outrasConsolas.length > 0) {
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        pdf.text('Outras Consolas Aceites:', margin, currentY)
        currentY += 8
        riderData.consolas.mon.outrasConsolas.forEach((consola, index) => {
          pdf.text(`${index + 1}. ${consola.marca} ${consola.modelo}`, margin + 20, currentY)
          currentY += 8
          if (consola.observacoes) {
            pdf.setFontSize(smallFontSize)
            pdf.setTextColor(100, 100, 100)
            pdf.text(`   Notas: ${consola.observacoes}`, margin + 25, currentY)
            currentY += 8
          }
        })
      }
      
      // Rodapé
      drawFooter()
       
       // SISTEMAS DE ESCUTA (nova página apenas se não for compacto)
       if (!exportOptions?.compactLayout) {
         pdf.addPage()
         pageNumber++
         currentY = margin
         drawPageHeader('Sistemas de Escuta')
       } else {
         currentY += 16
       }
       
      ensureSpace(24, 'Sistemas de Escuta')
      pdf.setFontSize(sectionFontSize)
      pdf.setFont('helvetica', 'bold')
      if (exportOptions?.compactLayout) { drawSeparator() }
      if (themeStyles.sectionTitleBg) {
        pdf.setFillColor(...themeStyles.sectionTitleBg)
        pdf.rect(margin - 2, currentY - 6, contentWidth + 4, 10, 'F')
      }
      pdf.setTextColor(...themeStyles.sectionTitleText)
      pdf.text('SISTEMAS DE ESCUTA', margin, currentY)
       
       currentY += themeStyles.sectionTopSpacing
       
       const sistemasEscuta = riderData['sistemas-escuta']
       let hasSistemasContent = false
       
       // IEMs
       if (sistemasEscuta?.iems?.quantidade && parseInt(sistemasEscuta.iems.quantidade) > 0) {
         hasSistemasContent = true
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'bold')
         pdf.setTextColor(0, 0, 0)
         pdf.text('IEMs (In-Ear Monitors):', margin, currentY)
         currentY += 8
         
         pdf.setFont('helvetica', 'normal')
         let iemText = `${sistemasEscuta.iems.quantidade}x IEMs`
         if (sistemasEscuta.iems.modeloPreferido) {
           iemText += ` - ${sistemasEscuta.iems.modeloPreferido}`
         }
         pdf.text(iemText, margin + 10, currentY)
         currentY += 8
         
         if (sistemasEscuta.iems.observacoes) {
           pdf.setFont('helvetica', 'italic')
           pdf.setTextColor(100, 100, 100)
           pdf.text(`Obs: ${sistemasEscuta.iems.observacoes}`, margin + 10, currentY)
           currentY += 8
         }
         currentY += 5
       }
       
       // Side Fills
       if (sistemasEscuta?.sideFills?.quantidade && parseInt(sistemasEscuta.sideFills.quantidade) > 0) {
         hasSistemasContent = true
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'bold')
         pdf.setTextColor(0, 0, 0)
         pdf.text('Side Fills:', margin, currentY)
         currentY += 8
         
         pdf.setFont('helvetica', 'normal')
         let sideFillText = `${sistemasEscuta.sideFills.quantidade}x Side Fills`
         if (sistemasEscuta.sideFills.modelo) {
           sideFillText += ` - ${sistemasEscuta.sideFills.modelo}`
         }
         pdf.text(sideFillText, margin + 10, currentY)
         currentY += 8
         
         if (sistemasEscuta.sideFills.observacoes) {
           pdf.setFont('helvetica', 'italic')
           pdf.setTextColor(100, 100, 100)
           pdf.text(`Obs: ${sistemasEscuta.sideFills.observacoes}`, margin + 10, currentY)
           currentY += 8
         }
         currentY += 5
       }
       
       // Wedges
       if (sistemasEscuta?.wedges?.quantidade && parseInt(sistemasEscuta.wedges.quantidade) > 0) {
         hasSistemasContent = true
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'bold')
         pdf.setTextColor(0, 0, 0)
         pdf.text('Wedges:', margin, currentY)
         currentY += 8
         
         pdf.setFont('helvetica', 'normal')
         let wedgeText = `${sistemasEscuta.wedges.quantidade}x Wedges`
         if (sistemasEscuta.wedges.modelo) {
           wedgeText += ` - ${sistemasEscuta.wedges.modelo}`
         }
         pdf.text(wedgeText, margin + 10, currentY)
         currentY += 8
         
         if (sistemasEscuta.wedges.observacoes) {
           pdf.setFont('helvetica', 'italic')
           pdf.setTextColor(100, 100, 100)
           pdf.text(`Obs: ${sistemasEscuta.wedges.observacoes}`, margin + 10, currentY)
           currentY += 8
         }
         currentY += 5
       }
       
       // Subs
       if (sistemasEscuta?.subs && sistemasEscuta.subs.length > 0) {
         hasSistemasContent = true
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'bold')
         pdf.setTextColor(0, 0, 0)
         pdf.text('Subs:', margin, currentY)
         currentY += 8
         
         sistemasEscuta.subs.forEach((sub, index) => {
           if (currentY > pageHeight - 40) {
             pdf.addPage()
             pageNumber++
             currentY = margin
           }
           
           pdf.setFont('helvetica', 'normal')
           let subText = `${sub.quantidade}x Subs`
           if (sub.modelo) {
             subText += ` - ${sub.modelo}`
           }
           if (sub.paraInstrumento) {
             subText += ` (para ${sub.paraInstrumento})`
           }
           pdf.text(subText, margin + 10, currentY)
           currentY += 8
           
           if (sub.observacoes) {
             pdf.setFont('helvetica', 'italic')
             pdf.setTextColor(100, 100, 100)
             pdf.text(`Obs: ${sub.observacoes}`, margin + 15, currentY)
             currentY += 8
           }
         })
         currentY += 5
       }
       
       if (!hasSistemasContent) {
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'italic')
         pdf.setTextColor(100, 100, 100)
         pdf.text('Nenhum sistema de escuta especificado', margin, currentY)
       }
       
       // Rodapé
       drawFooter()
       
       // EQUIPAMENTO AUXILIAR (nova página apenas se não for compacto)
       if (!exportOptions?.compactLayout) {
         pdf.addPage()
         pageNumber++
         currentY = margin
         drawPageHeader('Equipamento Auxiliar')
       } else {
         currentY += 16
       }
       
      ensureSpace(24, 'Equipamento Auxiliar')
      pdf.setFontSize(sectionFontSize)
      pdf.setFont('helvetica', 'bold')
      if (exportOptions?.compactLayout) { drawSeparator() }
      if (themeStyles.sectionTitleBg) {
        pdf.setFillColor(...themeStyles.sectionTitleBg)
        pdf.rect(margin - 2, currentY - 6, contentWidth + 4, 10, 'F')
      }
      pdf.setTextColor(...themeStyles.sectionTitleText)
      pdf.text('EQUIPAMENTO AUXILIAR', margin, currentY)
       
       currentY += themeStyles.sectionTopSpacing
       
       const equipamentoAuxiliar = riderData['equipamento-auxiliar']
       let hasContent = false
       
       // Talkbacks
       if (equipamentoAuxiliar?.talkbacks?.quantidade && parseInt(equipamentoAuxiliar.talkbacks.quantidade) > 0) {
         hasContent = true
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'bold')
         pdf.setTextColor(0, 0, 0)
         pdf.text('Talkbacks:', margin, currentY)
         currentY += 8
         
         pdf.setFont('helvetica', 'normal')
         let talkbackText = `${equipamentoAuxiliar.talkbacks.quantidade}x Talkbacks`
         if (equipamentoAuxiliar.talkbacks.modelo) {
           talkbackText += ` - ${equipamentoAuxiliar.talkbacks.modelo}`
         }
         pdf.text(talkbackText, margin + 10, currentY)
         currentY += 8
         
         if (equipamentoAuxiliar.talkbacks.observacoes) {
           pdf.setFont('helvetica', 'italic')
           pdf.setTextColor(100, 100, 100)
           pdf.text(`Obs: ${equipamentoAuxiliar.talkbacks.observacoes}`, margin + 10, currentY)
           currentY += 8
         }
         currentY += 5
       }
       
       // Intercom
       if (equipamentoAuxiliar?.intercom?.quantidade && parseInt(equipamentoAuxiliar.intercom.quantidade) > 0) {
         hasContent = true
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'bold')
         pdf.setTextColor(0, 0, 0)
         pdf.text('Intercom:', margin, currentY)
         currentY += 8
         
         pdf.setFont('helvetica', 'normal')
         let intercomText = `${equipamentoAuxiliar.intercom.quantidade}x Intercom`
         if (equipamentoAuxiliar.intercom.modelo) {
           intercomText += ` - ${equipamentoAuxiliar.intercom.modelo}`
         }
         pdf.text(intercomText, margin + 10, currentY)
         currentY += 8
         
         if (equipamentoAuxiliar.intercom.observacoes) {
           pdf.setFont('helvetica', 'italic')
           pdf.setTextColor(100, 100, 100)
           pdf.text(`Obs: ${equipamentoAuxiliar.intercom.observacoes}`, margin + 10, currentY)
           currentY += 8
         }
         currentY += 5
       }
       
       // Comunicação FOH/MON
       if (equipamentoAuxiliar?.comunicacaoFohMon?.tipo) {
         hasContent = true
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'bold')
         pdf.setTextColor(0, 0, 0)
         pdf.text('Comunicação FOH/MON:', margin, currentY)
         currentY += 8
         
         pdf.setFont('helvetica', 'normal')
         pdf.text(`Tipo: ${equipamentoAuxiliar.comunicacaoFohMon.tipo}`, margin + 10, currentY)
         currentY += 8
         
         if (equipamentoAuxiliar.comunicacaoFohMon.observacoes) {
           pdf.setFont('helvetica', 'italic')
           pdf.setTextColor(100, 100, 100)
           pdf.text(`Obs: ${equipamentoAuxiliar.comunicacaoFohMon.observacoes}`, margin + 10, currentY)
           currentY += 8
         }
         currentY += 5
       }
       
       // Observações gerais
       if (equipamentoAuxiliar?.observacoes) {
         hasContent = true
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'bold')
         pdf.setTextColor(0, 0, 0)
         pdf.text('Observações Gerais:', margin, currentY)
         currentY += 8
         
         pdf.setFont('helvetica', 'normal')
         pdf.setTextColor(100, 100, 100)
         const observacoes = equipamentoAuxiliar.observacoes
         const lines = pdf.splitTextToSize(observacoes, contentWidth - 20)
         
         lines.forEach(line => {
           if (currentY > pageHeight - 40) {
             pdf.addPage()
             pageNumber++
             currentY = margin
           }
           
           pdf.text(line, margin + 10, currentY)
           currentY += 6
         })
       }
       
       if (!hasContent) {
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'italic')
         pdf.setTextColor(100, 100, 100)
         pdf.text('Nenhum equipamento auxiliar especificado', margin, currentY)
       }
       
       // Rodapé
       drawFooter()
       
       // INPUT LIST (nova página apenas se não for compacto)
       if (!exportOptions?.compactLayout) {
         pdf.addPage()
         pageNumber++
         currentY = margin
         drawPageHeader('Input List')
       } else {
         currentY += 16
       }
       
      ensureSpace(24, 'Input List')
      pdf.setFontSize(sectionFontSize)
      pdf.setFont('helvetica', 'bold')
      if (exportOptions?.compactLayout) { drawSeparator() }
      if (themeStyles.sectionTitleBg) {
        pdf.setFillColor(...themeStyles.sectionTitleBg)
        pdf.rect(margin - 2, currentY - 6, contentWidth + 4, 10, 'F')
      }
      pdf.setTextColor(...themeStyles.sectionTitleText)
      pdf.text('INPUT LIST', margin, currentY)
       
       currentY += themeStyles.sectionTopSpacing
       
      if (riderData['input-list'] && riderData['input-list'].inputs && riderData['input-list'].inputs.length > 0) {
        drawTable({
          sectionTitle: 'Input List',
          startY: currentY,
          headerFill: themeStyles.tableHeaderFill,
          headerTextColor: themeStyles.tableHeaderText,
          columns: [
            { label: 'Canal', width: 20, getValue: (row) => row.canal || '' },
            { label: 'Fonte', width: 65, getValue: (row) => row.fonte || '' },
            { label: 'Micro/DI', width: 50, getValue: (row) => row.microDi || '' },
            { label: 'Stand', width: 25, getValue: (row) => row.stand || '' },
            { label: 'Phantom', width: 20, getValue: (row) => (row.phantom ? 'Sim' : 'Não') }
          ],
          rows: riderData['input-list'].inputs
        })
      } else {
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'italic')
        pdf.setTextColor(100, 100, 100)
        pdf.text('Nenhum equipamento especificado', margin, currentY)
      }
       
             // Rodapé
      drawFooter()
       

       // MONITOR MIXES (nova página apenas se não for compacto)
       if (!exportOptions?.compactLayout) {
         pdf.addPage()
         pageNumber++
         currentY = margin
         drawPageHeader('Monitor Mixes')
       } else {
         currentY += 16
       }
       
      ensureSpace(24, 'Monitor Mixes')
      pdf.setFontSize(sectionFontSize)
      pdf.setFont('helvetica', 'bold')
      if (exportOptions?.compactLayout) { drawSeparator() }
      if (themeStyles.sectionTitleBg) {
        pdf.setFillColor(...themeStyles.sectionTitleBg)
        pdf.rect(margin - 2, currentY - 6, contentWidth + 4, 10, 'F')
      }
      pdf.setTextColor(...themeStyles.sectionTitleText)
      pdf.text('MONITOR MIXES', margin, currentY)
       
       currentY += themeStyles.sectionTopSpacing
       
       if (riderData['monitor-mixes'] && riderData['monitor-mixes'].mixes && riderData['monitor-mixes'].mixes.length > 0) {
         const tipoLabels = { 'iem': 'IEM', 'wedge': 'Wedge', 'sidefill': 'Side Fill' }
         const formatoLabels = { 'mono': 'Mono', 'stereo': 'Stereo' }
         const getMixNumber = (mixes, idx) => {
           let channelNumber = 1
           for (let i = 0; i < idx; i++) {
             channelNumber += mixes[i]?.formato === 'stereo' ? 2 : 1
           }
           if (mixes[idx]?.formato === 'stereo') {
             const channel1 = channelNumber
             const channel2 = channelNumber + 1
             return `${channel1}/${channel2}`
           }
           return `${channelNumber}`
         }
        drawTable({
          sectionTitle: 'Monitor Mixes',
          startY: currentY,
          headerFill: themeStyles.tableHeaderFill,
          headerTextColor: themeStyles.tableHeaderText,
          columns: [
            { label: 'Mix', width: 20, getValue: (_row, i) => getMixNumber(riderData['monitor-mixes'].mixes, i) },
            { label: 'Instrumento/Músico', width: 85, getValue: (row) => row.instrumentoMusico || '' },
            { label: 'Tipo', width: 35, getValue: (row) => (tipoLabels[row.tipo] || row.tipo || '') },
            { label: 'Formato', width: 30, getValue: (row) => (formatoLabels[row.formato] || row.formato || '') }
          ],
          rows: riderData['monitor-mixes'].mixes
        })
       } else {
         pdf.setFontSize(bodyFontSize)
         pdf.setFont('helvetica', 'italic')
         pdf.setTextColor(100, 100, 100)
         pdf.text('Nenhum mix configurado', margin, currentY)
       }
       
       // Rodapé
       drawFooter()
       
       // OBSERVAÇÕES FINAIS (nova página apenas se não for compacto)
       if (!exportOptions?.compactLayout) {
         pdf.addPage()
         pageNumber++
         currentY = margin
         drawPageHeader('Observações Finais')
       } else {
         currentY += 16
       }
       
      ensureSpace(24, 'Observações Finais')
      pdf.setFontSize(sectionFontSize)
      pdf.setFont('helvetica', 'bold')
      if (exportOptions?.compactLayout) { drawSeparator() }
      if (themeStyles.sectionTitleBg) {
        pdf.setFillColor(...themeStyles.sectionTitleBg)
        pdf.rect(margin - 2, currentY - 6, contentWidth + 4, 10, 'F')
      }
      pdf.setTextColor(...themeStyles.sectionTitleText)
      pdf.text('OBSERVAÇÕES FINAIS', margin, currentY)
      
     currentY += themeStyles.sectionTopSpacing
     
      if (riderData['observacoes-finais'] && riderData['observacoes-finais'].observacoes) {
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'normal')
        pdf.setTextColor(0, 0, 0)
        
        const observacoes = riderData['observacoes-finais'].observacoes
        const lines = pdf.splitTextToSize(observacoes, contentWidth - 10)
        
        lines.forEach(line => {
          if (currentY > pageHeight - 40) {
            pdf.addPage()
            pageNumber++
            currentY = margin
          }
          
          pdf.text(line, margin + 5, currentY)
          currentY += 6
        })
      } else {
        pdf.setFontSize(bodyFontSize)
        pdf.setFont('helvetica', 'italic')
        pdf.setTextColor(100, 100, 100)
                 pdf.text('Nenhum equipamento especificado', margin, currentY)
      }
      
      // Rodapé final
      drawFooter()
      
      // Página final opcional: Stage Plot
      if (hasStagePlot) {
        pdf.addPage()
        pageNumber++
        currentY = margin
        drawPageHeader('Stage Plot')
        pdf.setFontSize(sectionFontSize)
        pdf.setFont('helvetica', 'bold')
        pdf.setTextColor(50, 50, 50)
        pdf.text('STAGE PLOT', margin, currentY)
        currentY += 10
        const sp = riderData['dados-gerais']?.stagePlot
        const format = (sp?.type || '').toLowerCase().includes('png') ? 'PNG' : 'JPEG'
        const maxW = contentWidth
        const maxH = pageHeight - margin * 2 - 10
        try {
          pdf.addImage(sp.data, format, margin, currentY, maxW, Math.min(maxH, maxW * 0.7))
        } catch (_) {}
        currentY = pageHeight - 20
        pdf.setFontSize(smallFontSize)
        pdf.setTextColor(100, 100, 100)
        pdf.text(`Página ${pageNumber} de ${totalPages}`, pageWidth - margin, currentY, { align: 'right' })
        pdf.text('Rider Forge', margin, currentY)
        if (exportOptions?.customFooter && exportOptions.customFooter.trim()) {
          pdf.text(exportOptions.customFooter.trim(), pageWidth / 2, currentY, { align: 'center' })
        }
      }

      // Salvar o PDF
      const fileName = `${riderName.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_rider.pdf`
      pdf.save(fileName)
      
    } catch (error) {
      console.error('Erro ao gerar PDF:', error)
      alert('Erro ao gerar o PDF. Tente novamente.')
    } finally {
      setIsGenerating(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-800 rounded-lg p-6 max-w-md w-full mx-4 border border-dark-700">
        <div className="text-center mb-6">
          <h3 className="text-xl font-bold text-gray-100 mb-2">Exportar PDF</h3>
          <p className="text-gray-400">Gerar rider técnico em formato PDF</p>
        </div>
        
        <div className="space-y-4 mb-6">
          <div className="bg-dark-700 rounded-lg p-4">
            <h4 className="text-sm font-medium text-gray-300 mb-2">Layout do PDF:</h4>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• Capa com nome do artista e contactos</li>
              <li>• Secções organizadas por sistemas (PA, Consolas, Sistemas de Escuta)</li>
              <li>• Input List em formato de tabela</li>
              <li>• Observações finais destacadas</li>
              <li>• Design profissional e limpo</li>
            </ul>
          </div>
          <div className="bg-dark-700 rounded-lg p-4 space-y-3">
            <h4 className="text-sm font-medium text-gray-300">Opções de Exportação</h4>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Tema do PDF</label>
              <select
                value={exportOptions.theme || 'base'}
                onChange={(e) => {
                  const val = e.target.value
                  if (val === 'base') {
                    setExportOptions(o => ({ ...o, theme: val }))
                  } else {
                    const ok = useProFeature(PRO_FEATURES.CUSTOM_PDF.id, () => true)
                    if (ok) setExportOptions(o => ({ ...o, theme: val }))
                  }
                }}
                className="w-full px-3 py-2 bg-dark-800 border border-dark-600 rounded-lg text-gray-100"
              >
                <option value="base">Base (Grátis)</option>
                <option value="pro_modern">Modern (Pro)</option>
                <option value="pro_minimal">Minimal (Pro)</option>
              </select>
            </div>
            <label className="flex items-center gap-2 text-sm text-gray-300">
              <input
                type="checkbox"
                checked={!!exportOptions.compactLayout}
                onChange={(e) => setExportOptions(o => ({ ...o, compactLayout: e.target.checked }))}
                className="w-4 h-4"
              />
              Layout compacto (menos páginas)
            </label>
            <label className="flex items-center gap-2 text-sm text-gray-300">
              <input
                type="checkbox"
                checked={exportOptions.includeStagePlot}
                onChange={(e) => setExportOptions(o => ({ ...o, includeStagePlot: e.target.checked }))}
                className="w-4 h-4"
              />
              Incluir Stage Plot (se existir)
            </label>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Rodapé personalizado (opcional)</label>
              <input
                type="text"
                value={exportOptions.customFooter}
                onChange={(e) => setExportOptions(o => ({ ...o, customFooter: e.target.value }))}
                className="w-full px-3 py-2 bg-dark-800 border border-dark-600 rounded-lg text-gray-100 placeholder-gray-500"
                placeholder="Texto de rodapé"
              />
            </div>
          </div>
          
          {/* Pro Features */}
          <div className="bg-gradient-to-r from-accent-blue/10 to-accent-green/10 rounded-lg p-4 border border-accent-blue/20">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-accent-blue text-sm">🔒</span>
              <h4 className="text-sm font-medium text-accent-blue">Funcionalidades Pro</h4>
            </div>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• Cores personalizáveis</li>
              <li>• Logo em todas as páginas</li>
              <li>• Rodapé personalizado</li>
              <li>• Múltiplos formatos de exportação</li>
            </ul>
          </div>
        </div>
        
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 bg-dark-700 text-gray-300 rounded-lg hover:bg-dark-600 transition-colors duration-200"
          >
            Cancelar
          </button>
          <button
            onClick={() => setShowPreview(true)}
            className="flex-1 px-4 py-2 bg-dark-600 text-gray-300 rounded-lg hover:bg-dark-500 transition-colors duration-200 flex items-center justify-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
            Preview
          </button>
          <button
            onClick={generatePDF}
            disabled={isGenerating}
            className="flex-1 px-4 py-2 bg-accent-blue text-white rounded-lg hover:bg-accent-blue/90 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <>
                <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Gerando...
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Exportar PDF
              </>
            )}
          </button>
        </div>
      </div>

      {/* PDF Preview Modal */}
      <PDFPreview
        isOpen={showPreview}
        riderData={riderData}
        riderName={riderName}
        exportOptions={exportOptions}
        onClose={() => setShowPreview(false)}
        onExport={() => {
          setShowPreview(false)
          generatePDF()
        }}
      />

      {/* Pro Upgrade Modal */}
      <ProUpgradeModal
        isOpen={showUpgradeModal}
        onClose={closeUpgradeModal}
        feature={currentFeature}
      />
    </div>
  )
}

export default PDFExport
